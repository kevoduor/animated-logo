// Cosmic color palette inspired by nebulae and celestial phenomena
export const cosmicColors = {
  nebulaPink: '#ff6b9f',
  cosmicPurple: '#9370DB',
  celestialBlue: '#4169E1',
  stardustGold: '#FFD700',
  mysticTeal: '#40E0D0',
  voidPurple: '#663399',
  auroraGreen: '#7FFF00',
  galaxyBlue: '#1E90FF',
} as const;

export const colorCombinations = [
  { colorA: cosmicColors.nebulaPink, colorB: cosmicColors.cosmicPurple },
  { colorA: cosmicColors.celestialBlue, colorB: cosmicColors.mysticTeal },
  { colorA: cosmicColors.stardustGold, colorB: cosmicColors.voidPurple },
  { colorA: cosmicColors.auroraGreen, colorB: cosmicColors.galaxyBlue },
];