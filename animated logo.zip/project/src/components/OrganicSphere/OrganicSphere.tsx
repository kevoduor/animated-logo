import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';
import vertexShader from './shaders/vertex.glsl';
import fragmentShader from './shaders/fragment.glsl';
import { colorCombinations } from '../../utils/colors';

export function OrganicSphere() {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const materialRef = useRef<THREE.ShaderMaterial | null>(null);
  const [colorIndex, setColorIndex] = useState(0);

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      100
    );
    camera.position.z = 2;
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Material setup
    const material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms: {
        uTime: { value: 0 },
        uNoiseFreq: { value: 1.5 },
        uNoiseAmp: { value: 0.2 },
        uColorA: { value: new THREE.Color(colorCombinations[colorIndex].colorA) },
        uColorB: { value: new THREE.Color(colorCombinations[colorIndex].colorB) },
      },
    });
    materialRef.current = material;

    // Geometry setup
    const geometry = new THREE.IcosahedronGeometry(1, 64);
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    // Animation
    const clock = new THREE.Clock();
    
    // Animate noise frequency
    gsap.to(material.uniforms.uNoiseFreq, {
      value: 2,
      duration: 2,
      yoyo: true,
      repeat: -1,
      ease: 'sine.inOut',
    });

    // Color transition animation
    const updateColors = () => {
      const nextIndex = (colorIndex + 1) % colorCombinations.length;
      gsap.to(material.uniforms.uColorA.value, {
        r: new THREE.Color(colorCombinations[nextIndex].colorA).r,
        g: new THREE.Color(colorCombinations[nextIndex].colorA).g,
        b: new THREE.Color(colorCombinations[nextIndex].colorA).b,
        duration: 2,
        ease: 'power2.inOut',
      });
      gsap.to(material.uniforms.uColorB.value, {
        r: new THREE.Color(colorCombinations[nextIndex].colorB).r,
        g: new THREE.Color(colorCombinations[nextIndex].colorB).g,
        b: new THREE.Color(colorCombinations[nextIndex].colorB).b,
        duration: 2,
        ease: 'power2.inOut',
        onComplete: () => setColorIndex(nextIndex),
      });
    };

    // Start color transition every 5 seconds
    const colorInterval = setInterval(updateColors, 5000);

    const animate = () => {
      const elapsedTime = clock.getElapsedTime();
      material.uniforms.uTime.value = elapsedTime * 0.5;
      
      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    };
    animate();

    // Handle resize
    const handleResize = () => {
      if (!containerRef.current) return;
      
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;

      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      clearInterval(colorInterval);
      containerRef.current?.removeChild(renderer.domElement);
      geometry.dispose();
      material.dispose();
      renderer.dispose();
    };
  }, [colorIndex]);

  return <div ref={containerRef} className="w-full h-full" />;
}