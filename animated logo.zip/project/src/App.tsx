import React from 'react';
import { OrganicSphere } from './components/OrganicSphere/OrganicSphere';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
      <div className="w-64 h-64">
        <OrganicSphere />
      </div>
    </div>
  );
}

export default App;