import { useState, useEffect } from 'react';

export function useOrbAnimation() {
  const [scale, setScale] = useState(1);

  useEffect(() => {
    let animationFrame: number;
    let time = 0;

    const animate = () => {
      time += 0.02;
      const newScale = 1 + Math.sin(time) * 0.05;
      setScale(newScale);
      animationFrame = requestAnimationFrame(animate);
    };

    animate();
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  return { scale };
}